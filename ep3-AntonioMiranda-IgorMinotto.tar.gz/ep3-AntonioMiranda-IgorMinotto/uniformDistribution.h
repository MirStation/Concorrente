#ifndef UNIFORMD
#define UNIFORMD

#include <stdlib.h>

int uniform_distribution(int rangeLow, int rangeHigh);

#endif
