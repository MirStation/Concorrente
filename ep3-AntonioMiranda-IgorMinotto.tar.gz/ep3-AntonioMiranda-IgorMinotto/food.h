#ifndef FOOD_H
#define FOOD_H
typedef unsigned int Food;
#endif
